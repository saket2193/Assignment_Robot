import numpy as np
def list_sort(nums):
    nums.sort()
    print('List in Ascending Order: ', nums)
    for i in nums:
        print(i)
        if i%2 == 0:
            calc=i**2
            print(calc)
    return nums

x = np.array([2, 1, 4, 3, 5])
list_sort(x)
Step 1: Python Installation
Check if Python is installed on your system.

python --version
pip --version

Step 2: Install Robot Framework

The suggested route to install the robot framework on Python is to use pip. We can use the undermentioned command to install the framework.

pip install robotframework

Step 3: Verifying Installation

After the well-turned installation, we should be able to see both interpreter and robot framework versions using the –version option.

robot --version
rebot --version

Step 4: Check robot framework is installed properly

pip show robotframework

Step 5: Run tests
robot -d results -i Smoke -i Sanity Tests/testsuite1.robot
robot -d results -i Smoke -i Sanity Tests/testsuite2.robot

-i Smoke -i Sanity will ensure that all tests are executed with the ‘Smoke’ and Sanity Tags. So from our test, only Test Case 1,2,3 will be executed.
import numpy as np
def list_sort_citi(cities):
    cities.sort()
    print('List in Ascending Order: ', cities)
    return cities

x = np.array(["Delhi", "Bangalore", "Hyderabad", "Gujarat", "Punjab"])
list_sort_citi(x)